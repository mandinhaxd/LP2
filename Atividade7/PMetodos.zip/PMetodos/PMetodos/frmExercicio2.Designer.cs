﻿namespace PMetodos
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.btnigual = new System.Windows.Forms.Button();
            this.btninserir1 = new System.Windows.Forms.Button();
            this.btninserir2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(123, 112);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(74, 20);
            this.lblPalavra1.TabIndex = 0;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(123, 160);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(74, 20);
            this.lblpalavra2.TabIndex = 1;
            this.lblpalavra2.Text = "Palavra 2";
            this.lblpalavra2.Click += new System.EventHandler(this.Lblpalavra2_Click);
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(203, 109);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(100, 26);
            this.txtPalavra1.TabIndex = 2;
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(203, 160);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(100, 26);
            this.txtPalavra2.TabIndex = 3;
            // 
            // btnigual
            // 
            this.btnigual.Location = new System.Drawing.Point(79, 252);
            this.btnigual.Name = "btnigual";
            this.btnigual.Size = new System.Drawing.Size(110, 56);
            this.btnigual.TabIndex = 4;
            this.btnigual.Text = "Verificar se são iguais";
            this.btnigual.UseVisualStyleBackColor = true;
            this.btnigual.Click += new System.EventHandler(this.Btnigual_Click);
            // 
            // btninserir1
            // 
            this.btninserir1.Location = new System.Drawing.Point(245, 252);
            this.btninserir1.Name = "btninserir1";
            this.btninserir1.Size = new System.Drawing.Size(110, 56);
            this.btninserir1.TabIndex = 5;
            this.btninserir1.Text = "Inserir 1";
            this.btninserir1.UseVisualStyleBackColor = true;
            this.btninserir1.Click += new System.EventHandler(this.Btninserir1_Click);
            // 
            // btninserir2
            // 
            this.btninserir2.Location = new System.Drawing.Point(405, 252);
            this.btninserir2.Name = "btninserir2";
            this.btninserir2.Size = new System.Drawing.Size(110, 56);
            this.btninserir2.TabIndex = 6;
            this.btninserir2.Text = "Inserir 2";
            this.btninserir2.UseVisualStyleBackColor = true;
            this.btninserir2.Click += new System.EventHandler(this.Btninserir2_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninserir2);
            this.Controls.Add(this.btninserir1);
            this.Controls.Add(this.btnigual);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.Button btnigual;
        private System.Windows.Forms.Button btninserir1;
        private System.Windows.Forms.Button btninserir2;
    }
}