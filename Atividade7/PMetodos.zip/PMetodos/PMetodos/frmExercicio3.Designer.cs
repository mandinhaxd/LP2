﻿namespace PMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btninverte = new System.Windows.Forms.Button();
            this.btnremover2 = new System.Windows.Forms.Button();
            this.btnremover1 = new System.Windows.Forms.Button();
            this.txtPalavra2 = new System.Windows.Forms.TextBox();
            this.txtPalavra1 = new System.Windows.Forms.TextBox();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblPalavra1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btninverte
            // 
            this.btninverte.Location = new System.Drawing.Point(508, 269);
            this.btninverte.Name = "btninverte";
            this.btninverte.Size = new System.Drawing.Size(110, 56);
            this.btninverte.TabIndex = 13;
            this.btninverte.Text = "Inverte";
            this.btninverte.UseVisualStyleBackColor = true;
            this.btninverte.Click += new System.EventHandler(this.Btninverte_Click);
            // 
            // btnremover2
            // 
            this.btnremover2.Location = new System.Drawing.Point(348, 269);
            this.btnremover2.Name = "btnremover2";
            this.btnremover2.Size = new System.Drawing.Size(110, 56);
            this.btnremover2.TabIndex = 12;
            this.btnremover2.Text = "Remover 2";
            this.btnremover2.UseVisualStyleBackColor = true;
            this.btnremover2.Click += new System.EventHandler(this.Btnremover2_Click);
            // 
            // btnremover1
            // 
            this.btnremover1.Location = new System.Drawing.Point(182, 269);
            this.btnremover1.Name = "btnremover1";
            this.btnremover1.Size = new System.Drawing.Size(110, 56);
            this.btnremover1.TabIndex = 11;
            this.btnremover1.Text = "Remover 1";
            this.btnremover1.UseVisualStyleBackColor = true;
            this.btnremover1.Click += new System.EventHandler(this.Btnremover1_Click);
            // 
            // txtPalavra2
            // 
            this.txtPalavra2.Location = new System.Drawing.Point(306, 177);
            this.txtPalavra2.Name = "txtPalavra2";
            this.txtPalavra2.Size = new System.Drawing.Size(100, 26);
            this.txtPalavra2.TabIndex = 10;
            // 
            // txtPalavra1
            // 
            this.txtPalavra1.Location = new System.Drawing.Point(306, 126);
            this.txtPalavra1.Name = "txtPalavra1";
            this.txtPalavra1.Size = new System.Drawing.Size(100, 26);
            this.txtPalavra1.TabIndex = 9;
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(226, 177);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(74, 20);
            this.lblpalavra2.TabIndex = 8;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // lblPalavra1
            // 
            this.lblPalavra1.AutoSize = true;
            this.lblPalavra1.Location = new System.Drawing.Point(226, 129);
            this.lblPalavra1.Name = "lblPalavra1";
            this.lblPalavra1.Size = new System.Drawing.Size(74, 20);
            this.lblPalavra1.TabIndex = 7;
            this.lblPalavra1.Text = "Palavra 1";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btninverte);
            this.Controls.Add(this.btnremover2);
            this.Controls.Add(this.btnremover1);
            this.Controls.Add(this.txtPalavra2);
            this.Controls.Add(this.txtPalavra1);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblPalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btninverte;
        private System.Windows.Forms.Button btnremover2;
        private System.Windows.Forms.Button btnremover1;
        private System.Windows.Forms.TextBox txtPalavra2;
        private System.Windows.Forms.TextBox txtPalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblPalavra1;
    }
}