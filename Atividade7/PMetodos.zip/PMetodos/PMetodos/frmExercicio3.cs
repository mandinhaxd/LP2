﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void Btnremover1_Click(object sender, EventArgs e)
        {
            int posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text,
                StringComparison.OrdinalIgnoreCase);
            while (posicao >= 0)
            {
                txtPalavra2.Text= txtPalavra2.Text.Substring(0, posicao) +
                    txtPalavra2.Text.Substring(posicao + txtPalavra1.Text.Length,
                    txtPalavra2.Text.Length - posicao - txtPalavra1.Text.Length);

                posicao = txtPalavra2.Text.IndexOf(txtPalavra1.Text,
                StringComparison.OrdinalIgnoreCase);
            }
        }

        private void Btnremover2_Click(object sender, EventArgs e)
        {
            txtPalavra1.Text = txtPalavra1.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.ToUpper();
            txtPalavra2.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void Btninverte_Click(object sender, EventArgs e)
        {
            //trasnforma string em array de char
            char[] vetorC = txtPalavra1.Text.ToCharArray();
            // inverter o array(vetor)
            Array.Reverse(vetorC);
            //voltar vetor para string
            foreach (char C in vetorC)
                txtPalavra2.Text += C;
            //ou
            txtPalavra2.Text = new string(vetorC);
        }
    }
}
