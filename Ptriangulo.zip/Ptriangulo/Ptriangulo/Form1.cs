﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
     

        private void Txt1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txt1, "");
            double valor1;
            
            if(!double.TryParse(txt1.Text, out valor1))
            {
                errorProvider1.SetError(txt1, "Valor de A inválido!");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txt2, "");
            double valor2;

            if (!double.TryParse(txt2.Text, out valor2))
            {
                errorProvider2.SetError(txt2, "Valor de B inválido!");
            }
        }

        private void Txt3_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txt3, "");
            double valor3;

            if (!double.TryParse(txt3.Text, out valor3))
            {
                errorProvider3.SetError(txt3, "Valor de C inválido!");
            }
        }

        private void Btncalc_Click(object sender, EventArgs e)
        {
            double valor1, valor2, valor3;
            if (!double.TryParse(txt1.Text, out valor1) ||
                !double.TryParse(txt2.Text, out valor2) ||
                !double.TryParse(txt3.Text, out valor3))
            {
                MessageBox.Show("Valores devem ser numéricos");
            }
            else
            {
                if (valor1 < (valor2 + valor3) && valor1 >
                    Math.Abs(valor2 - valor3) && valor2 < (valor1+valor3)
                    && valor2>Math.Abs(valor1-valor3) &&
                    valor3<(valor1+valor2)&&
                    valor3> Math.Abs(valor1-valor2))
                {
                    if(valor1==valor2 && valor2==valor3)
                        MessageBox.Show($"Os valores {valor1}, {valor2} e {valor3} formam um triângulo equilátero");
                    else
                    {
                        if(valor1==valor2 || valor1==valor3 || valor3==valor2)
                            MessageBox.Show($"Os valores {valor1}, {valor2} e {valor3} formam um triângulo isósceles");
                        else
                            MessageBox.Show($"Os valores {valor1}, {valor2} e {valor3} formam um triângulo escaleno");
                    }
                }
                else
                    MessageBox.Show($"Os valores {valor1}, {valor2} e {valor3} NÃO formam um triângulo");
            }

        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {
            txt1.Text = "";
            txt2.Text = "";
            txt3.Text = "";
          
            txt1.Focus();
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja realmente sair?",
               "Saída", MessageBoxButtons.YesNo,
               MessageBoxIcon.Question) ==
               DialogResult.Yes)
            {
                Close();
            }
        }
    }
}
