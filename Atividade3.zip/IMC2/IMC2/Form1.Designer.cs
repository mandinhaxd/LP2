﻿
namespace IMC2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btncalc = new System.Windows.Forms.Button();
            this.txtaltura = new System.Windows.Forms.TextBox();
            this.txtimc = new System.Windows.Forms.TextBox();
            this.txtmassa = new System.Windows.Forms.TextBox();
            this.lblimc = new System.Windows.Forms.Label();
            this.lblaltura = new System.Windows.Forms.Label();
            this.lblmassa = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(417, 160);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 19);
            this.button2.TabIndex = 17;
            this.button2.Text = "Limpar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(417, 193);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 20);
            this.button1.TabIndex = 16;
            this.button1.Text = "Sair";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btncalc
            // 
            this.btncalc.Location = new System.Drawing.Point(407, 107);
            this.btncalc.Margin = new System.Windows.Forms.Padding(2);
            this.btncalc.Name = "btncalc";
            this.btncalc.Size = new System.Drawing.Size(71, 37);
            this.btncalc.TabIndex = 15;
            this.btncalc.Text = "Calcular";
            this.btncalc.UseVisualStyleBackColor = true;
            this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
            // 
            // txtaltura
            // 
            this.txtaltura.Location = new System.Drawing.Point(289, 162);
            this.txtaltura.Margin = new System.Windows.Forms.Padding(2);
            this.txtaltura.Name = "txtaltura";
            this.txtaltura.Size = new System.Drawing.Size(68, 20);
            this.txtaltura.TabIndex = 14;
            this.txtaltura.Validated += new System.EventHandler(this.txtaltura_Validated);
            // 
            // txtimc
            // 
            this.txtimc.Enabled = false;
            this.txtimc.Location = new System.Drawing.Point(289, 193);
            this.txtimc.Margin = new System.Windows.Forms.Padding(2);
            this.txtimc.Name = "txtimc";
            this.txtimc.Size = new System.Drawing.Size(68, 20);
            this.txtimc.TabIndex = 13;
            // 
            // txtmassa
            // 
            this.txtmassa.Location = new System.Drawing.Point(289, 131);
            this.txtmassa.Margin = new System.Windows.Forms.Padding(2);
            this.txtmassa.Name = "txtmassa";
            this.txtmassa.Size = new System.Drawing.Size(68, 20);
            this.txtmassa.TabIndex = 12;
            this.txtmassa.Validated += new System.EventHandler(this.txtmassa_Validated);
            // 
            // lblimc
            // 
            this.lblimc.AutoSize = true;
            this.lblimc.Location = new System.Drawing.Point(217, 197);
            this.lblimc.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblimc.Name = "lblimc";
            this.lblimc.Size = new System.Drawing.Size(26, 13);
            this.lblimc.TabIndex = 11;
            this.lblimc.Text = "IMC";
            // 
            // lblaltura
            // 
            this.lblaltura.AutoSize = true;
            this.lblaltura.Location = new System.Drawing.Point(217, 162);
            this.lblaltura.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblaltura.Name = "lblaltura";
            this.lblaltura.Size = new System.Drawing.Size(51, 13);
            this.lblaltura.TabIndex = 10;
            this.lblaltura.Text = "Altura (m)";
            // 
            // lblmassa
            // 
            this.lblmassa.AutoSize = true;
            this.lblmassa.Location = new System.Drawing.Point(217, 131);
            this.lblmassa.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblmassa.Name = "lblmassa";
            this.lblmassa.Size = new System.Drawing.Size(60, 13);
            this.lblmassa.TabIndex = 9;
            this.lblmassa.Text = "Massa (Kg)";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btncalc);
            this.Controls.Add(this.txtaltura);
            this.Controls.Add(this.txtimc);
            this.Controls.Add(this.txtmassa);
            this.Controls.Add(this.lblimc);
            this.Controls.Add(this.lblaltura);
            this.Controls.Add(this.lblmassa);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btncalc;
        private System.Windows.Forms.TextBox txtaltura;
        private System.Windows.Forms.TextBox txtimc;
        private System.Windows.Forms.TextBox txtmassa;
        private System.Windows.Forms.Label lblimc;
        private System.Windows.Forms.Label lblaltura;
        private System.Windows.Forms.Label lblmassa;
    }
}

